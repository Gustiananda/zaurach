export const Prices = [
  {
    _id: 0,
    nama: "Rp.0 - 25.000",
    array: [0, 25000],
  },
  {
    _id: 1,
    nama: "Rp.20.000 - 50.000",
    array: [20000, 50000],
  },
  {
    _id: 2,
    nama: "Rp.50.000 - 75.000",
    array: [50000, 75000],
  },
  {
    _id: 3,
    nama: "Rp.75.000 - 100.000",
    array: [75000, 100000],
  },
  {
    _id: 4,
    nama: "Rp.100.000 or more",
    array: [100000, 999999],
  },
];
